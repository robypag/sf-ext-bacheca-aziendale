/* eslint-disable no-undef */
sap.ui.define(["sap/fe/core/AppComponent"], function (AppComponent) {
    "use strict";

    return AppComponent.extend("itg.sf.bachecaadmin.Component", {
        metadata: {
            manifest: "json",
        },
    });
});
