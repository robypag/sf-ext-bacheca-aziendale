/* eslint-disable no-undef */
sap.ui.define(["sap/ui/core/mvc/Controller"], function (Controller) {
    "use strict";
    return Controller.extend("itg.bachecaadmin.ext.controller.FileUpload", {
        onInit: function () {},
    });
});
